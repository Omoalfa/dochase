<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="HandheldFriendly" content="true" />
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    
    <link href="css/styles.css" rel="stylesheet" />
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lity/2.4.0/lity.min.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.24.1/feather.min.js" crossorigin="anonymous"></script>
    -->
    <title>Dochase Promo</title>
    <style type="text/css">
        .custom_body{
          padding: 0;
          margin: 0;
          width: 100%;
          height:100%;
        }
        .transbox{
            width: 100%;
            background-color: white;
            opacity: 1;
            margin: auto;
            margin-top: 5%;
        }
    </style>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg bg-white navbar-light fixed-top" style="font-weight: 500;">
    <a class="navbar-brand text-white" href="index.html"><img src="img/dochase_logo.png" width="150" height="100" alt=""/></a><button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-lg-4">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item ml-lg-2 dropdown no-caret">
                <a class="nav-link dropdown-toggle" id="navbarDropdownPages" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Advertiser</a>
                <div class="dropdown-menu dropdown-menu-center animated--fade-in-up" aria-labelledby="navbarDropdownPages">
                    <div class="row no-gutters">
                        <a class="dropdown-item" href="https://dochase.com/advertiser.html#advertiser-guide" target="_blank">Advertiser Guide</a><a class="dropdown-item" href="https://dochase.com/advertiser.html#advertiser-faq" target="_blank">Advertiser FAQ</a>
                        <div class="dropdown-divider border-0"></div>
                    </div>
                </div>
            </li>
            <li class="nav-item ml-lg-2 dropdown no-caret">
                <a class="nav-link dropdown-toggle" id="navbarDropdownPages" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Publisher</a>
                <div class="dropdown-menu dropdown-menu-center animated--fade-in-up" aria-labelledby="navbarDropdownPages">
                    <div class="row no-gutters">
                        <a class="dropdown-item" href="https://dochase.com/publisher.html#publisher-guide" target="_blank">Publisher Guide</a><a class="dropdown-item" href="https://dochase.com/publisher.html#publisher-faq" target="_blank">Publisher FAQ</a>
                        <div class="dropdown-divider border-0"></div>
                    </div>
                </div>
            </li>
            <li class="nav-item ml-lg-2 dropdown no-caret">
                <a class="nav-link dropdown-toggle" id="navbarDropdownPages" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Programmatic Solutions</a>
                <div class="dropdown-menu dropdown-menu-center animated--fade-in-up" aria-labelledby="navbarDropdownPages">
                    <div class="row no-gutters">
                        <a class="dropdown-item" href="https://dochase.com/demand-side-platform.html" target="_blank">DSP</a><a class="dropdown-item" href="https://dochase.com/supply-side-platform.html" target="_blank">SSP</a><a class="dropdown-item" href="https://dochase.com/sentiment-analysis.html" target="_blank">Sentiment Analysis</a><a class="dropdown-item" href="https://dochase.com/programmatic-solutions.html#display-advertising" target="_blank">Display Advertising</a><a class="dropdown-item" href="https://dochase.com/programmatic-solutions.html#native-advertising" target="_blank">Native Advertising</a><a class="dropdown-item" href="https://dochase.com/programmatic-solutions.html#direct-to-mobile" target="_blank">Direct To Mobile</a><a class="dropdown-item" href="https://dochase.com/programmatic-solutions.html#sms-tagging" target="_blank">SMS Tagging</a><a class="dropdown-item" href="https://dochase.com/programmatic-solutions.html#interactive-voice-response" target="_blank">Interactive Voice Response</a><a class="dropdown-item" href="https://dochase.com/programmatic-solutions.html#click-to-ussd" target="_blank">USSD</a>
                        <div class="dropdown-divider border-0"></div>
                    </div>
                </div>
            </li>
            <li class="nav-item ml-lg-2 dropdown no-caret">
                <a class="nav-link dropdown-toggle" id="navbarDropdownPages" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Case Studies</a>
                <div class="dropdown-menu dropdown-menu-center animated--fade-in-up" aria-labelledby="navbarDropdownPages">
                    <div class="row no-gutters">
                        <a class="dropdown-item" href="https://dochase.com/case-studies.html#sports-betting" target="_blank">Sports Betting</a><a class="dropdown-item" href="https://dochase.com/case-studies.html#finance" target="_blank">Finance</a><a class="dropdown-item" href="https://dochase.com/case-studies.html#sexual-health" target="_blank">Sexual Health</a><a class="dropdown-item" href="https://dochase.com/case-studies.html#real-estate" target="_blank">Real Estate</a><a class="dropdown-item" href="https://dochase.com/case-studies.html#beer-brands" target="_blank">Beer Brands</a><a class="dropdown-item" href="https://dochase.com/case-studies.html#mobile-phones" target="_blank">Mobile Phones</a>
                        <div class="dropdown-divider border-0"></div>
                    </div>
                </div>
            </li>
            <li class="nav-item ml-lg-2"><a class="nav-link" href="https://dochase.com/rich-media.html" target="_blank">Rich Media</a></li>
            <li class="nav-item ml-lg-2"><a class="nav-link" href="https://dochase.com/dochase-chatbot.html" target="_blank">Chatbot</a></li>
            <li class="nav-item ml-lg-2 dropdown no-caret">
                <a class="nav-link dropdown-toggle" id="navbarDropdownAboutUs" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Company</a>
                <div class="dropdown-menu dropdown-menu-center animated--fade-in-up" aria-labelledby="navbarDropdownAboutUs">
                    <div class="row no-gutters">
                        <a class="dropdown-item" href="https://dochase.com/about-us.html" target="_blank">About Us</a><a class="dropdown-item" href="https://dochase.com/index.html#contact-us" target="_blank">Contact Us</a>
                        <div class="dropdown-divider border-0"></div>
                    </div>
                </div>
            </li>
        </ul>
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link px-4 ml-lg-2" href="https://dashboard.dochase.com/" target="_blank">Login</a></li>
        </ul>
        <div class="dropdown">
            <button class="btn-teal btn rounded-pill px-4 ml-lg-2 dropdown-toggle" id="dropdownMenuButton" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Signup</button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="https://dashboard.dochase.com/register" target="_blank">Advertiser Signup</a>
                <div class="dropdown-divider border-0"></div>
                <a class="dropdown-item" href="https://monetize.dochase.com/#apply" target="_blank">Publisher Signup</a>
            </div>
        </div>
    </div>
</nav>