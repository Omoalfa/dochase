<?php 
session_start();
include("./includes/header.php");
use AfricasTalking\SDK\AfricasTalking;
require './includes/vendor/autoload.php';
include('./includes/dbconfig.php');

date_default_timezone_set('Africa/Lagos');

$ref = "dochasePromo/";
$getdata = $database->getReference($ref)->getValue();
$leads_count = count($getdata);
?>
<div class ="custom_body">
    <!--<div style="overflow:hidden; max-width:100%; height: 130px;">
        <iframe src="https://dochase.co/programmatic.html" scrolling="no" style="border: 0px none; margin-left: 0px; height: 130px; margin-top: 0px; width: 100%;">
        </iframe>
    </div>-->
    
    <div class="transbox">
      <div class="col-md-6 offset-md-3">
        <!--<img src="./img/promo_show.png" width="100%" alt="SportyBet Promo">-->
        <div class="carousel slide" id="richMediaCarousel" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active"><img class="img-fluid content-skewed-item shadow-lg" src="img/promo_show1.png" width="100%" alt="Dochase Promo" /></div>
                <div class="carousel-item"><img class="img-fluid content-skewed-item shadow-lg" src="img/promo_show1.png" width="100%" alt="Dochase Promo" /></div>
                <div class="carousel-item"><img class="img-fluid content-skewed-item shadow-lg" src="img/promo_show1.png" width="100%" alt="Dochase Promo" /></div>
            </div>
            <a class="carousel-control-prev" href="#richMediaCarousel" role="button" data-slide="prev"><span class="carousel-control-prev-icon" aria-hidden="true"></span><span class="sr-only">Previous</span></a
            ><a class="carousel-control-next" href="#richMediaCarousel" role="button" data-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="sr-only">Next</span></a>
        </div>
        
        <?php
            if(isset($_SESSION["wrongNumber"]) && $_SESSION["wrongNumber"] != ""){?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION["wrongNumber"]?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php unset($_SESSION["wrongNumber"]); }
            elseif(isset($_SESSION["noReward"]) && $_SESSION["noReward"] != ""){ 
            ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo $_SESSION["noReward"]?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION["noReward"]); } 
            elseif(isset($_SESSION["status"]) && $_SESSION["status"] != ""){ 
            ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION["status"]?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION["status"]); } 
            elseif(isset($_SESSION["duplicate"]) && $_SESSION["duplicate"] != ""){ 
            ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION["duplicate"]?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php unset($_SESSION["duplicate"]);
            } ?>

        <form action="code.php" method="post" validate="validate">
            <div class="alert alert-info text-center" role="alert">
                Fill in details below to join the Raffle Draw. If you win, you get credited instantly!
            </div>
            
            <div class="input-group">
                <input type="email" name="emailAddress" class="form-control" placeholder="Enter email address" required>
            </div><br>
            
            <div class="input-group">
                <input type="text" name="phoneNumber" class="form-control" placeholder="Enter phone number, format: +23481XXX" required>
            </div>
            <hr>
            
            <input type="submit" name="submit" value="Submit" class="btn btn-success btn-flat btn-block btn-lg ">
               
        </form>
      </div>
    </div>
</div>
    
<?php include("./includes/footer.php")?>