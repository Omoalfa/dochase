<?php 
include("./includes/header.php");
?>

<section class="bg-white py-10">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 mt-5">
                <h1>Terms &amp; Privacy</h1>
                <p class="lead">Last updated: December 2020</p>
                <hr class="my-5" />
                <h2 class="mb-3">1. Overview</h2>
                <p>These Terms and Conditions ("the Terms and Conditions") govern your ("the User") use of the promo.dochase.co ("Provider") website located at the subdomain name www.dochase.co ("the Website"). By accessing and using the Website, the User agrees to be bound by the Terms and Conditions set out in this legal notice.</p>
                <hr class="my-5" />
                <h2 class="mb-3">2. Unconditional Rights</h2>
                <p>The Provider supplies services to advertisers and third party website operators. Advertisements from advertisers are contextually matched to the best content available on our third party website operators. The parties involved in this process are Advertisers (users that pay for advertising) and Publishers (users that operate websites and place our ads on their content). Access to the Website is provided at the discretion of the Provider and access may be revoked at any time for no reason.</p>
                <hr class="my-5" />
                <h2 class="mb-3">3. Advertisers</h2>
                <p>The nature of the advertising is Pay Per Click and the advertiser will pay a fee per click each time their ads are clicked. The cost of this click is determined by the Provider's algorithms, which will remain confidential at all times. The cost of the click will never exceed the advertisers maximum cost per click, which is pre-set by the User on the Website and may be adjusted from time to time by the User.</p>
                <p>The overall expenditure of the advertiser will never exceed the daily budget. Costs are billed based on risk and ad delivery algorithms and the advertiser, by loading their credit card details onto the Website, authorizes the Provider to collect costs on a weekly basis according to the expenditure that has taken place.</p>
                <hr class="my-5" />
                <h2 class="mb-3">4. Publishers/Source</h2>
                <p>Publishers/SSP are users participating with the Website to deliver advertisements. Publishers will receive agreed share (usually majority share) of all revenue paid by advertisers. Payment to Publishers will be made on a monthly basis by the Provider, as long as earnings by the Publisher reach N3000; payments are processed to the publisher on confirmation that the publisher is not guilty of fraud clicks, within 7 (seventheen) days after each month.</p>
                <p>Publishers may not click on an advertisement on their own Website to increase earnings. Dochase.co reserves the right to deduct any transactions detected as fraudulent. Dochase may serve advertisements sourced from 3rd parties, such as ad networks.</p>
                <hr class="my-5" />
                <h2 class="mb-3">5. Click Fraud</h2>
                <p>If Provider determines that click fraud has taken place - usually when a publisher wishes to increase their earnings unfairly or an advertiser wishes to deplete a competitive advertiser's daily budget - then the Provider reserves the right to reverse any revenues or charges related to the fraud, and to suspend the account of the infringing party with immediate effect.</p>
                <hr class="my-5" />
                <h2 class="mb-3">6. Pre-Vetting</h2>
                <p>Some publishers/SSP may be provided with the functionality to pre-qualify advertisers in order to ensure that they are acceptable and do not conflict with the publishers advertising policies. These publishers will not use the pre-vetting functionality for lead generation - in other words, the Provider is listing its advertisers in good faith and these advertisers may not be approached directly by the publisher.</p>
                <hr class="my-5" />
                <h2 class="mb-3">7. Copyright</h2>
                <p>The User may not access, display, use, download, and/or otherwise copy or distribute Content obtained on the website for marketing and other purposes without the consent of the Provider. The Provider provides certain information at the Website. Content currently or anticipated to be displayed at this Website is provided by Provider, its affiliates and/or subsidiary, or any other third party owners of such content, and includes but is not limited to Literary Works, Musical Works, Artistic Works, Sound Recordings, Cinematograph Films, Sound and Television Broadcasts, Program-Carrying Signals, Published Editions and Computer Programs ("the Content").</p>
                <p>All such proprietary works, and the compilation of the proprietary works, are copyright the Provider, its affiliates or subsidiary, or any other third party owner of such rights ("the Owners"), and is protected by International copyright laws. The Providers reserve the right to make any changes to the Website, the Content, or to products and/or services offered through the Website at any times and without notice.</p>
                <p>All rights in and to the Content is reserved and retained by the Owners. Except as specified in these Terms and Conditions, the User is not granted a license or any other right including without limitation under Copyright, Trademark, Patent or other Intellectual Property Rights in or to the Content.</p>
                <hr class="my-5" />
                <h2 class="mb-3">8. Electronic Communications</h2>
                <p>By using this Website or communicating with the Provider by electronic means, the user consents and acknowledges that any and all agreements, notices, disclosures, or any other communication satisfies any legal requirement, including but not limited to the requirement that such communications should be in writing.</p>
                <hr class="my-5" />
                <h2 class="mb-3">9. E-Commerce &amp; Privacy</h2>
                <p>The Website (www.dochase.co) provides online pay per click advertising services. The purchase of any services from this Website is at the purchaser's risk. The purchaser / user indemnifies and holds the Provider harmless against any loss, injury or damages which may be sustained as a result of using the services provided on the Website.</p>
                <p>Alternative payment methods are provided for Users that do not wish to pay using a Paypal at the moment.</p>
                <p>The private information required for executing the orders placed through the e-commerce facility, namely the User's personal or company information and credit card details, address and telephone numbers will be kept in the strictest confidence by the Provider and not sold or made known to third parties.</p>
                <p>No private information shall be shared with any third parties without prior consent of the User.</p>
                <hr class="my-5" />
                <h2 class="mb-3">10. Cancellation Policy</h2>
                <p>If the User is not satisfied with the service received, written notice must be provided to the Provider in writing with 7 (seven) working days from which the advertisement was activated, stating the particular advertisement with which they are not satisfied. On receipt of this notice of cancellation the Provider will refund the User within a period of 7 working days - refunds will be made using the original payment method used by the User.</p>
                <hr class="my-5" />
                <h2 class="mb-3">11. Updating of these Terms and Conditions</h2>
                <p>Dochase reserves the right to change, modify, add to or remove from portions or the whole of these Terms and Conditions from time to time. Changes to these Terms and Conditions will become effective upon such changes being posted to this Website. It is the User's obligation to periodically check these Terms and Conditions at the Website for changes or updates. The User's continued use of this Website following the posting of changes or updates will be considered notice of the User's acceptance to abide by and be bound by these Terms and Conditions, including such changes or updates.</p>
                <hr class="my-5" />
                <h2 class="mb-3">12. Limitation of liability</h2>
                <p>The Website and all Content on the Website, including any current or future offer of products or services, are provided on an "as is" basis, and may include inaccuracies or typographical errors. The Owners make no warranty or representation as to the availability, accuracy or completeness of the Content. Neither Provider nor any holding company, affiliate or subsidiary of Provider, shall be held responsible for any direct or indirect special, consequential or other damage of any kind whatsoever suffered or incurred, related to the use of, or the inability to access or use the Content or the Website or any functionality thereof, or of any linked website, even if Provider is expressly advised thereof.</p>
                <hr class="my-5" />
                <h2 class="mb-3">13. Non Profit Organization Advertising</h2>
                <p>In certain situations the Provider may be unable to match relevant advertising to the Content on the Website. In this case, the Provider reserves the right to deliver Non Profit Organization Advertisements (NPOA) - the Website will receive no revenue from clicks originating from these advertisements and it is recorded that the Provider also receives no revenue from delivering these advertisements.</p>
                <hr class="my-5" />
                <h2 class="mb-3">14. Privacy: casual surfing</h2>
                <p>The User may visit the Website without providing any personal information. The Website servers will in such instances collect the IP address of the User computer, but not the email address or any other distinguishing information. This information is aggregated to measure the number of visits, average time spent at the Website, pages viewed, etc. Provider uses this information to determine use of the Website, and to improve Content thereon. Provider assumes no obligation to protect this information, and may copy, distribute or otherwise use such information without limitation.</p>
                <hr class="my-5" />
                <h2 class="mb-3">15. Quality of Data</h2>
                <p>Much of the data input into the Website is received by Users who are (a) posting an advertisement (advertisers) or (b) publishing advertisements (publishers). The Website cannot guarantee the quality of this data, and whilst we will endeavor to ensure optimal qualify and validity of all data, we cannot accept any responsibility for faulty or misleading data input by third parties.</p>
                <hr class="my-5" />
                <div class="card z-1 mb-n10">
                    <div class="card-body text-center py-5">
                        <h2 class="mb-3">We're always available to help</h2>
                        <a class="btn btn-teal btn-marketing rounded-pill" href="https://dochase.co/index.html#contact-us" target="_blank">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="svg-border-rounded text-teal">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 144.54 17.34" preserveAspectRatio="none" fill="currentColor"><path d="M144.54,17.34H0V0H144.54ZM0,0S32.36,17.34,72.27,17.34,144.54,0,144.54,0"></path></svg>
    </div>
</section>
<?php include("./includes/footer.php")?>