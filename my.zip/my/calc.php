<?php
/*
$date=date_create("2020-10-21");

echo date_format($date,"Y-m-d");

$new_date = date_add($date,date_interval_create_from_date_string("7 days"));
echo date_format($new_date,"Y-m-d");


$old_date = date_format($date,"Y-m-d");
echo gettype($old_date);
$real_date =date("Y-m-d");

echo gettype($real_date);

if($old_date == $real_date){
    echo "yes";
}else{
    echo "No";
}


$real_date =date("Y-m-d");

$now_today = date_create($real_date);

$diff=date_diff($date,$now_today)*/
$lead_count = 5;

if($lead_count % 5 == 0){
    echo "Not a lucky winner";
}
else{
    echo "You have won the airtime";
}

?>