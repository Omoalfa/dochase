<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="HandheldFriendly" content="true" />
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    
    <link href="css/styles.css" rel="stylesheet" />
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lity/2.4.0/lity.min.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.24.1/feather.min.js" crossorigin="anonymous"></script>
    -->
    <title>Dochase Promo</title>
    <style type="text/css">
        .custom_body{
          padding: 0;
          margin: 0;
          width: 100%;
          height:100%;
        }
        .transbox{
            width: 100%;
            background-color: white;
            opacity: 1;
            margin: auto;
            margin-top: 10%;
        }
    </style>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg bg-white navbar-light fixed-top" style="font-weight: 500;">
    <a class="navbar-brand text-white" href="index.php"><img src="img/dochase_logo.png" width="150" alt=""/></a><button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item ml-lg-3"><a class="nav-link" href="https://dochase.co/dochase-chatbot.html">Chatbot</a></li>
            <li class="nav-item ml-lg-3"><a class="nav-link" href="https://dochase.co/rich-media.html">Rich Media</a></li>
            <li class="nav-item ml-lg-3"><a class="nav-link" href="https://dochase.co/sentiment-analysis.html">Sentiment Analysis</a></li>
            <li class="nav-item dropdown no-caret ml-lg-3">
                <a class="nav-link dropdown-toggle" id="navbarDropdownPages" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Case Studies</a>
                <div class="dropdown-menu dropdown-menu-center animated--fade-in-up" aria-labelledby="navbarDropdownPages">
                    <div class="row no-gutters">
                        <a class="dropdown-item" href="https://dochase.co/case-studies.html#sports-betting">Sports Betting</a><a class="dropdown-item" href="https://dochase.co/case-studies.html#finance">Finance</a><a class="dropdown-item" href="https://dochase.co/case-studies.html#sexual-health">Sexual Health</a><a class="dropdown-item" href="https://dochase.co/case-studies.html#real-estate">Real Estate</a><a class="dropdown-item" href="https://dochase.co/case-studies.html#beer-brands">Beer Brands</a><a class="dropdown-item" href="https://dochase.co/case-studies.html#mobile-phones">Mobile Phones</a>
                        <div class="dropdown-divider border-0"></div>
                    </div>
                </div>
            </li>
            <li class="nav-item dropdown no-caret ml-lg-3">
                <a class="nav-link dropdown-toggle" id="navbarDropdownPages" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Mobile Use</a>
                <div class="dropdown-menu dropdown-menu-center animated--fade-in-up" aria-labelledby="navbarDropdownPages">
                    <div class="row no-gutters">
                        <a class="dropdown-item" href="https://dochase.co/programmatic.html#click-to-whatsapp">Click to WhatsApp</a><a class="dropdown-item" href="https://dochase.co/programmatic.html#click-to-ussd">Click to USSD</a><a class="dropdown-item" href="https://dochase.co/programmatic.html#click-to-call">Click to Call</a>
                        <div class="dropdown-divider border-0"></div>
                    </div>
                </div>
            </li>
            <li class="nav-item ml-lg-3"><a class="nav-link btn-teal btn rounded-pill px-4 ml-lg-2" href="https://dochase.co/index.html#contact-us">Contact Us</a></li>
        </ul>
    </div>
</nav>